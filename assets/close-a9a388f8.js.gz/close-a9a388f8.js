const c="/assets/close-c3681c65.png";export{c};
