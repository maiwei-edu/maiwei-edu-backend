import{I as o,D as r,L as s}from"./Dragger-1df363a5.js";const a=o;a.Dragger=r;a.LIST_IGNORE=s;const p=a;export{p as U};
