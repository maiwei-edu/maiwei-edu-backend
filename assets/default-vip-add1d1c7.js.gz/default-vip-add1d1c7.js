const a="/assets/default-vip-a4e54a05.png";export{a as v};
